import city1 from "../images/1.jpg";
import city2 from "../images/2.jpg";
import city3 from "../images/3.jpg";

export const images = [
  { title: "San Diego", subtitle: "San Diego City", img: city1 },
  { title: "Vivetnam", subtitle: "Vivetnam City", img: city2 },
  { title: "Vancouver", subtitle: "Vancouver City", img: city3 },
];
