import styled from "styled-components";

export default styled.div`
  display: "flex";
  justifycontent: "center";
  alignitems: "center";
  width: "100%";
  margin: "18px 15px";
`;
