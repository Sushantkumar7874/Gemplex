import React from "react";
import { Grid } from "@material-ui/core";
import { Height } from "@material-ui/icons";

const Languages = () => {
  return (
    <>
      <div style={{ margin: "12px" }}>
        <h4>Languages</h4>
        <Grid container spacing={2}>
        <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
               E
            </h1>
            <p>&nbsp; &nbsp; English</p>
          </Grid>
          <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
              आ
            </h1>
            <p>&nbsp; &nbsp;  Hindi</p>
          </Grid>
          <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
              अ
            </h1>
            <p>&nbsp; &nbsp; Marathi</p>
          </Grid>
          <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
              ক
            </h1>
            <p>&nbsp; &nbsp;Bangla</p>
          </Grid>
          <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
              ಎ
            </h1>
            <p>&nbsp; &nbsp;Kannad</p>
          </Grid>
         
          <Grid item>
            <h1
              lg={3}
              style={{
                backgroundColor: "#1b70a8",
                borderRadius: "100%",
                height: "95px",
                width: "95px",
                textAlign: "center",
                marginTop: "15px",
              }}
            >
              ਏ
            </h1>
            <p>&nbsp; &nbsp;Punjabi</p>
          </Grid>
        </Grid>
      </div>
    </>
  );
};

export default Languages;
