import React from "react";

const Advertise = () => {
  return (
    <>
      <div>
        <img
          src="https://preprod-gemplex-web.s3.ap-south-1.amazonaws.com/gemplex-web_ad01-1280-300.jpg"
          width="100%"
          height="150px"
        ></img>
      </div>
    </>
  );
};

export default Advertise;
